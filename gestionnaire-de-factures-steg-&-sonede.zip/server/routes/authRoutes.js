
const express = require('express');
const router = express.Router();
// Ici viendront les contrôleurs de Login et Signup
// Pour l'instant, nous définissons les points d'entrée requis par server.js

router.post('/signup', (req, res) => res.json({ message: "Route Signup prête" }));
router.post('/login', (req, res) => res.json({ message: "Route Login prête" }));

module.exports = router;
