
import { configureStore, createSlice, PayloadAction, createAsyncThunk } from '@reduxjs/toolkit';
import { Invoice, Centre, Societe } from './types';
import { apiService } from './services/apiService';

// --- ACTIONS ASYNCHRONES : AUTHENTIFICATION ---

export const loginThunk = createAsyncThunk(
  'auth/login',
  async (credentials: { email: string; pass: string }) => {
    return await apiService.post('/auth/login', credentials);
  }
);

export const signupThunk = createAsyncThunk(
  'auth/signup',
  async (userData: { nom: string; email: string; pass: string }) => {
    return await apiService.post('/auth/signup', userData);
  }
);

// --- ACTIONS ASYNCHRONES : FACTURES ---

export const fetchInvoices = createAsyncThunk('invoices/fetchAll', async () => {
  return await apiService.get('/factures');
});

export const addInvoiceThunk = createAsyncThunk(
  'invoices/add',
  async (invoice: Omit<Invoice, 'id'>) => {
    return await apiService.post('/factures', invoice);
  }
);

export const updateInvoiceThunk = createAsyncThunk(
  'invoices/update',
  async (invoice: Invoice) => {
    return await apiService.put(`/factures/${invoice.id}`, invoice);
  }
);

export const deleteInvoiceThunk = createAsyncThunk(
  'invoices/delete',
  async (id: string) => {
    await apiService.delete(`/factures/${id}`);
    return id;
  }
);

// --- ACTIONS ASYNCHRONES : CENTRES ---

export const fetchCentres = createAsyncThunk('centres/fetchAll', async () => {
  return await apiService.get('/centres');
});

export const addCentreThunk = createAsyncThunk(
  'centres/add',
  async (centre: Omit<Centre, 'id'>) => {
    return await apiService.post('/centres', centre);
  }
);

export const updateCentreThunk = createAsyncThunk(
  'centres/update',
  async (centre: Centre) => {
    return await apiService.put(`/centres/${centre.id}`, centre);
  }
);

export const deleteCentreThunk = createAsyncThunk(
  'centres/delete',
  async (id: string) => {
    await apiService.delete(`/centres/${id}`);
    return id;
  }
);

// --- SLICES ---

interface AuthState {
  user: Societe | null;
  status: 'idle' | 'loading' | 'failed';
}

const initialAuth: AuthState = {
  user: JSON.parse(localStorage.getItem('factupro_user') || 'null'),
  status: 'idle'
};

const authSlice = createSlice({
  name: 'auth',
  initialState: initialAuth,
  reducers: {
    logout: (state) => {
      state.user = null;
      localStorage.removeItem('factupro_user');
    }
  },
  extraReducers: (builder) => {
    builder
      .addCase(loginThunk.fulfilled, (state, action) => {
        state.user = action.payload;
        localStorage.setItem('factupro_user', JSON.stringify(action.payload));
      })
      .addCase(signupThunk.fulfilled, (state, action) => {
        state.user = action.payload;
        localStorage.setItem('factupro_user', JSON.stringify(action.payload));
      });
  }
});

interface InvoiceState {
  items: Invoice[];
  isLoading: boolean;
}

const initialInvoices: InvoiceState = {
  items: [],
  isLoading: false
};

const invoiceSlice = createSlice({
  name: 'invoices',
  initialState: initialInvoices,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchInvoices.pending, (state) => { state.isLoading = true; })
      .addCase(fetchInvoices.fulfilled, (state, action) => {
        state.items = action.payload;
        state.isLoading = false;
      })
      .addCase(addInvoiceThunk.fulfilled, (state, action) => {
        state.items.unshift(action.payload);
      })
      .addCase(updateInvoiceThunk.fulfilled, (state, action) => {
        const index = state.items.findIndex(i => i.id === action.payload.id);
        if (index !== -1) state.items[index] = action.payload;
      })
      .addCase(deleteInvoiceThunk.fulfilled, (state, action) => {
        state.items = state.items.filter(i => i.id !== action.payload);
      });
  }
});

interface CentreState {
  items: Centre[];
}

const initialCentres: CentreState = {
  items: []
};

const centreSlice = createSlice({
  name: 'centres',
  initialState: initialCentres,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchCentres.fulfilled, (state, action) => {
        state.items = action.payload;
      })
      .addCase(addCentreThunk.fulfilled, (state, action) => {
        state.items.push(action.payload);
      })
      .addCase(updateCentreThunk.fulfilled, (state, action) => {
        const index = state.items.findIndex(c => c.id === action.payload.id);
        if (index !== -1) state.items[index] = action.payload;
      })
      .addCase(deleteCentreThunk.fulfilled, (state, action) => {
        state.items = state.items.filter(c => c.id !== action.payload);
      });
  }
});

interface UIState {
  theme: 'light' | 'dark';
}

const initialUI: UIState = {
  theme: (localStorage.getItem('factupro_theme') as 'light' | 'dark') || 'dark'
};

const uiSlice = createSlice({
  name: 'ui',
  initialState: initialUI,
  reducers: {
    toggleTheme: (state) => {
      state.theme = state.theme === 'light' ? 'dark' : 'light';
      localStorage.setItem('factupro_theme', state.theme);
    }
  }
});

export const store = configureStore({
  reducer: {
    auth: authSlice.reducer,
    ui: uiSlice.reducer,
    invoices: invoiceSlice.reducer,
    centres: centreSlice.reducer
  }
});

export const { logout } = authSlice.actions;
export const { toggleTheme } = uiSlice.actions;

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
