
const express = require('express');
const router = express.Router();
const { getCentres, createCentre, updateCentre, deleteCentre } = require('../controllers/centreController');
const auth = require('../middleware/auth');

router.get('/', auth, getCentres);
router.post('/', auth, createCentre);
router.put('/:id', auth, updateCentre);
router.delete('/:id', auth, deleteCentre);

module.exports = router;
